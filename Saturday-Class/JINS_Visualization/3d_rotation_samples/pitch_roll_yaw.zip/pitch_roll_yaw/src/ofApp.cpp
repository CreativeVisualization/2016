#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    ofBackground(32);
    ofEnableSmoothing();
    
    ofSetSmoothLighting(true);
    
    dir.setDiffuseColor(ofColor(200.0f, 200.0f, 200.0f));
    dir.setSpecularColor(ofColor(255.0f, 255.0f, 255.0f));
    
    dir.setDirectional();
    dir_rot = ofVec3f(135,0,30);
    setLightOri(dir, dir_rot);
    
    amb.setAmbientColor(ofColor(50.0, 50.0, 50.0));
    
    amb.enable();
    dir.enable();
    
    gui.setup("panel");
    gui.add(pitch.set( "pitch", 0, -45, 45 ));
    gui.add(roll.set( "roll", 0, -45, 45 ));
    
    

}

//--------------------------------------------------------------
void ofApp::update(){
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    
    cam.begin();

    
    ofEnableAlphaBlending();
    glEnable(GL_DEPTH_TEST);

    ofPushMatrix();
    
    //ofRotateZ(roll);
    //ofRotateX(pitch);
    
    
    ofVec3f axisZ = ofVec3f(0, 0, 1);
    ofVec3f axisX = ofVec3f(1, 0, 0);
    
    ofQuaternion rotation;
    float rotationAmount;
    ofVec3f rotationAngle;
    
    //roll と　pitchの値から回転を計算
    rotation.makeRotate(roll, axisZ, pitch, axisX, 0, axisZ);
    rotation.getRotate(rotationAmount, rotationAngle);
    ofRotate(rotationAmount, rotationAngle.x, rotationAngle.y, rotationAngle.z);
    
    
    
    ofDrawBox(0, 0, 0, 200);

    ofPopMatrix();

    glDisable(GL_DEPTH_TEST);
    ofDisableAlphaBlending();
    
    
    
    cam.end();
    
    
    gui.draw();
    

    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

//--------------------------------------------------------------
void ofApp::setLightOri(ofLight &light, ofVec3f rot)
{
    ofVec3f xax(1, 0, 0);
    ofVec3f yax(0, 1, 0);
    ofVec3f zax(0, 0, 1);
    ofQuaternion q;
    q.makeRotate(rot.x, xax, rot.y, yax, rot.z, zax);
    light.setOrientation(q);
}
